package com.newProject.Rakesh.PersoDto;

public class PersonDTO {
    private String name;
    private String image;
}
