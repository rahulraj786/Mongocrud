package com.newProject.Rakesh.CustomException;

public class PersonNotFoundException extends RuntimeException{
    public PersonNotFoundException(String id) {
        super("Person not found with id: " + id);
    }
}
