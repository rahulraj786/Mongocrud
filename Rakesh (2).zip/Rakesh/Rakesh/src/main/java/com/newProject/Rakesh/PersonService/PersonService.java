package com.newProject.Rakesh.PersonService;

import com.newProject.Rakesh.Entity.Person;
import com.newProject.Rakesh.PersoDto.PersonDTO;
import org.springframework.stereotype.Service;

@Service
public interface PersonService {
    Person createPerson(PersonDTO personDTO);
    Person getPersonById(String id);
    void deletePersonById(String id);
    Person updatePerson(String id, PersonDTO personDTO);
}
