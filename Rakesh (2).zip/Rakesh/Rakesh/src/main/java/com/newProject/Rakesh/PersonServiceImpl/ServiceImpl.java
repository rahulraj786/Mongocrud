package com.newProject.Rakesh.PersonServiceImpl;

import com.newProject.Rakesh.CustomException.PersonNotFoundException;
import com.newProject.Rakesh.Entity.Person;
import com.newProject.Rakesh.PersoDto.PersonDTO;
import com.newProject.Rakesh.PersonRepo.PersonRepo;
import com.newProject.Rakesh.PersonService.PersonService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;

public class ServiceImpl implements PersonService {
    @Autowired
    private PersonRepo personRepository;

    @Override
    public Person createPerson(PersonDTO personDTO) {
        Person person = new Person();
        BeanUtils.copyProperties(personDTO, person);
        return personRepository.save(person);
    }



    @Override
    public Person getPersonById(String id) {
        return personRepository.findById(id)
                .orElseThrow(() -> new PersonNotFoundException(id));
    }

    @Override
    public void deletePersonById(String id) {
        personRepository.findById(id)
                .ifPresentOrElse(personRepository::delete, () -> {
                    throw new PersonNotFoundException(id);
                });
    }

    @Override
    public Person updatePerson(String id, PersonDTO personDTO) {
        Person existingPerson = getPersonById(id);
        BeanUtils.copyProperties(personDTO, existingPerson);
        return personRepository.save(existingPerson);
    }
}
