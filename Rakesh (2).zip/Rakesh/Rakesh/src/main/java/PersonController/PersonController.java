package PersonController;

import com.newProject.Rakesh.Entity.Person;
import com.newProject.Rakesh.PersoDto.PersonDTO;
import com.newProject.Rakesh.PersonService.PersonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/persons")
public class PersonController {

    @Autowired
    private PersonService personService;

    @PostMapping("/save")
    public ResponseEntity<Person> createPerson(@RequestBody PersonDTO personDTO) {
        return ResponseEntity.ok(personService.createPerson(personDTO));
    }

    @GetMapping("/id")
    public ResponseEntity<Person> getPersonById(@PathVariable String id) {
        return ResponseEntity.ok(personService.getPersonById(id));
    }

    @DeleteMapping("/id")
    public ResponseEntity<String> deletePersonById(@PathVariable String id) {
        personService.deletePersonById(id);
        return ResponseEntity.ok("Person deleted successfully");
    }

    @PutMapping("/id")
    public ResponseEntity<Person> updatePerson(@PathVariable String id, @RequestBody PersonDTO personDTO) {
        return ResponseEntity.ok(personService.updatePerson(id, personDTO));
    }
}
