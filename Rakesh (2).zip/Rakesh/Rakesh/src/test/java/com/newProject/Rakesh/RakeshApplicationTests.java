package com.newProject.Rakesh;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RakeshApplicationTests {

	@Test
	void contextLoads() {
	}

}
